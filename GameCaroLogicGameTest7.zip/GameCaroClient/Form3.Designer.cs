﻿namespace GameCaroClient
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Location = new Point(228, 114);
            panel1.Name = "panel1";
            panel1.Size = new Size(588, 399);
            panel1.TabIndex = 0;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(255, 192, 255);
            button5.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button5.ForeColor = Color.MediumOrchid;
            button5.Location = new Point(386, 303);
            button5.Name = "button5";
            button5.Size = new Size(188, 74);
            button5.TabIndex = 4;
            button5.Text = "LỊCH SỬ";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 192, 255);
            button4.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button4.ForeColor = Color.BlueViolet;
            button4.Location = new Point(36, 303);
            button4.Name = "button4";
            button4.Size = new Size(188, 74);
            button4.TabIndex = 3;
            button4.Text = "BXH";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 192);
            button3.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button3.ForeColor = Color.Green;
            button3.Location = new Point(386, 37);
            button3.Name = "button3";
            button3.Size = new Size(188, 74);
            button3.TabIndex = 2;
            button3.Text = "CÀI ĐẶT";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 255, 192);
            button2.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button2.ForeColor = Color.Gold;
            button2.Location = new Point(36, 37);
            button2.Name = "button2";
            button2.Size = new Size(188, 74);
            button2.TabIndex = 1;
            button2.Text = "PROFILE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Font = new Font("UTM Cookies", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.RoyalBlue;
            button1.Location = new Point(187, 146);
            button1.Name = "button1";
            button1.Size = new Size(246, 123);
            button1.TabIndex = 0;
            button1.Text = "BẮT ĐẦU";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.GIAODIEN2_011;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1066, 692);
            Controls.Add(panel1);
            DoubleBuffered = true;
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
    }
}