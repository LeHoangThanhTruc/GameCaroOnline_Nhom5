﻿namespace GameCaroClient
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            button3 = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Transparent;
            checkBox1.Font = new Font("UTM Cookies", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox1.ForeColor = Color.FromArgb(128, 128, 255);
            checkBox1.Location = new Point(387, 307);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(334, 44);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "ÂM THANH HỆ THỐNG";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.Transparent;
            checkBox2.Font = new Font("UTM Cookies", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox2.ForeColor = Color.FromArgb(255, 192, 128);
            checkBox2.Location = new Point(387, 393);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(180, 44);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "NHẠC NỀN";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 192);
            button3.Font = new Font("UTM Cookies", 13.8F, FontStyle.Bold);
            button3.ForeColor = Color.Green;
            button3.Location = new Point(705, 503);
            button3.Name = "button3";
            button3.Size = new Size(151, 52);
            button3.TabIndex = 3;
            button3.Text = "OK";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.SETTING_01;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1066, 692);
            Controls.Add(button3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            DoubleBuffered = true;
            Name = "Form7";
            Text = "Form7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private Button button3;
    }
}