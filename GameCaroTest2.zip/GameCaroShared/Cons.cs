﻿namespace GameCaroShared
{
    public class Cons
    {
        public static int CHESS_WIDTH = 30;
        public static int CHESS_HEIGHT = 30;
        public static int CHESS_BOARD_HEIGHT = 22;
        public static int CHESS_BOARD_WIDTH = 23;
        public static int COOL_DOWN_STEP = 100;
        public static int COOL_DOWN_TIME = 10000; //10s = 10000ms
        public static int COOL_DOWN_INTERVAL = 100; //100ms = 1/10s
    }
}
